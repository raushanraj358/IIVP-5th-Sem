clear
Img = imread('2.jpg');
Img = rgb2gray(Img);
a = [0.2,0.3,0.4,1,2,12];
A = 2;

Img1 = A*(double(Img).^a(1));
Img2 = A*(double(Img).^a(2));
Img3 = A*(double(Img).^a(3));
Img4 = A*(double(Img).^a(4));
Img5 = A*(double(Img).^a(5));
Img6 = A*(double(Img).^a(6));

subplot(3,2,1);
imshow(uint8(Img1));
title('a = 0.2');
subplot(3,2,2);
imshow(uint8(Img2));
title('a = 0.3');
subplot(3,2,3);
imshow(uint8(Img3));
title('a = 0.4');
subplot(3,2,4);
imshow(uint8(Img4));
title('a = 1');
subplot(3,2,5);
imshow(uint8(Img5));
title('a = 2');
subplot(3,2,6);
imshow(uint8(Img6));
title('a = 12');