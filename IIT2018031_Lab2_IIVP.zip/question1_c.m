 clc; 
b = imread('2.jpg'); 
bd = double(b); 
  
b6 = mod(floor(cd/32), 2); 
b7 = mod(floor(cd/64), 2); 
b8 = mod(floor(cd/128), 2); 


subplot(2, 4, 1); 
imshow(b); 
title('Original Image'); 
  
subplot(2, 4, 2); 
imshow(b6); 
title('Bit Plane 6'); 
subplot(2, 4, 3); 
imshow(b7); 
title('Bit Plane 7');
subplot(2, 4, 4); 
imshow(b8); 
title('Bit Plane 8'); 
  