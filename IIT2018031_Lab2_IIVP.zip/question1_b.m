clear
I = imread('2.jpg');
I = rgb2gray(I);
mx = max(I,[],'all');
I(I>=110 & I<=200) = mx - I(I>=110 & I<=200);
imshow(I);
title('Question1B output');