I1 = imread('I1.jpg');

R = size(I1,1);
C = size(I1,2);
D = size(I1,3);
for i = 1:R
    for j = C:-1:1
        for k = 1:D
            I2(i,C-j+1,k) = I1(i,j,k);
        end
    end
end

for i = 1:2*R
    for j = 1:C
        for k = 1:D
            if i <= R
                Vert_Cat(i,j,k) = I1(i,j,k);
            else
                Vert_Cat(i,j,k) = I2(i-R,j,k);
            end
        end
    end
end

imshow(Vert_Cat);