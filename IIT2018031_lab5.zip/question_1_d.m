img=imread("image.jpg");
img1=imresize(img,[256 256]);
hist1 = histeq(img1);

img2=imread("Q1_b.png");
hist2 = histeq(img2);

subplot(1,2,1);
imshow(hist1);

subplot(1,2,2);
imshow(hist2);