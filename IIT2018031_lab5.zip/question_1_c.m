img = imread('image.jpg'); 
modified_img = imresize(img,[256 265]);
normalized_img = uint8(256*mat2gray(modified_img));
%imshow(normalized_img);

imgNew = zeros(254,254,'uint8');
val=zeros(1,8);
for i=2:255
    for j=2:255
        ind=1;
        for x=i-1:i+1
            for y=j-1:j+1
                if x~=i || y~=j
                    if normalized_img(x,y)>=normalized_img(i,j)
                        val(ind)=1;
                    else
                        val(ind)=0;
                    end
                    ind=ind+1;
                end
            end
        end
        imgNew(i-1,j-1) = bin2dec(num2str(val));
    end
end

%imshow(imgNew);
histogram(imgNew);
%imhist(imgNew);