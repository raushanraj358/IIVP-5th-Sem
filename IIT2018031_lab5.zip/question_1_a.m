img = imread('image.jpg'); 
modified_img = imresize(img,[256 265]);
normalized_img = uint8(256*mat2gray(modified_img));
imshow(normalized_img);
>> 