>> z = imread('Lenna_(test_image).png'); 

z = rgb2gray(z);

ab = double(z); 

z1 = mod(ab, 2); 
z2 = mod(floor(ab/2), 2); 
z3 = mod(floor(ab/4), 2); 
z4 = mod(floor(ab/8), 2); 
z5 = mod(floor(ab/16), 2); 
z6 = mod(floor(ab/32), 2); 
z7 = mod(floor(ab/64), 2); 
z8 = mod(floor(ab/128), 2); 

pq = (2 * (2 * (2 * (2 * (2 * (2 * (2 * z8 + z7) + z6) + z5) + z4) + z3) + z2) + z1); 

subplot(3, 5, 1); 
imshow(z); 
title('Original Image'); 

subplot(3, 4, 2); 
imshow(z1); 
title('B P 1'); 
subplot(3, 4, 3); 
imshow(z2); 
title('B P 2'); 
subplot(3, 4, 4); 
imshow(z3); 
title('B P 3'); 
subplot(3, 4, 5); 
imshow(z4); 
title('B P 4'); 
subplot(3, 4, 6); 
imshow(z5); 
title('B P 5'); 
subplot(3, 4, 7); 
imshow(z6); 
title('B P 6'); 
subplot(3, 4, 8); 
imshow(z7); 
title('B P 7'); 
subplot(3, 4, 9); 
imshow(z8); 
title('B P 8'); 

subplot(3, 4, 10); 
imshow(uint8(pq)); 
title('Rezombined');
