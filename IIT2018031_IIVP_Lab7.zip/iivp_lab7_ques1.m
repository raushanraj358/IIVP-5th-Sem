z = imread('Lenna_(test_image.png)'); 
z = rgb2gray(z);
pq = double(z); 
z1 = mod(pq, 2); 
z2 = mod(floor(pq/2), 2); 
z3 = mod(floor(pq/4), 2); 
z4 = mod(floor(pq/8), 2); 
z5 = mod(floor(pq/16), 2); 
z6 = mod(floor(pq/32), 2); 
z7 = mod(floor(pq/64), 2); 
z8 = mod(floor(pq/128), 2); 

zz = (2 * (2 * (2 * (2 * (2 * (2 * (2 * z8 + z7) + z6) + z5) + z4) + z3) + z2) + z1); 

subplot(3, 5, 1); 
imshow(z); 
title('Original Image'); 

subplot(3, 4, 2); 
imshow(z1); 
title('B P 1'); 
subplot(3, 4, 3); 
imshow(z2); 
title('B P 2'); 
subplot(3, 4, 4); 
imshow(z3); 
title('B P 3'); 
subplot(3, 4, 5); 
imshow(z4); 
title('B P 4'); 
subplot(3, 4, 6); 
imshow(z5); 
title('B P 5'); 
subplot(3, 4, 7); 
imshow(z6); 
title('B P 6'); 
subplot(3, 4, 8); 
imshow(z7); 
title('B P 7'); 
subplot(3, 4, 9); 
imshow(z8); 
title('B P 8'); 

subplot(3, 4, 10); 
imshow(uint8(zz)); 
title('Rezombined');

B=[1 1 1 1 1 1 1;];
z=padarray(z1,[0 3]);
D=false(size(z1));
for i=1:size(z,1)
    for j=1:size(z,2)-6
        D(i,j)=sum(B&z(i,j:j+6));
    end
end
subplot(3,4,11);
imshow(D);
title('B1 Dilate');

B=[1 1 1 1 1 1 1;];
z=padarray(z3,[0 3]);
D=false(size(z3));
for i=1:size(z,1)
    for j=1:size(z,2)-6
        D(i,j)=sum(B&z(i,j:j+6));
    end
end
subplot(3,4,12);
imshow(D);
title('B3 Dilate');

B=[1 1 1 1 1 1 1;];
z=padarray(z7,[0 3]);
D=false(size(z7));
for i=1:size(z,1)
    for j=1:size(z,2)-6
        D(i,j)=sum(B&z(i,j:j+6));
    end
end
subplot(3,4,13);
imshow(D);
title('B7 Dilate');


A=z1;
%Struzturing element
B=[1 1 1 1 1 1 1;];
%Pad array with ones on both sides
z=padarray(A,[0 1],1);
%Intialize the matrix D of size A with zeros
D=false(size(A));
for i=1:size(z,1)
    for j=1:size(z,2)-2
        L=z(i,j:j+2);
 %Find the position of ones in the struzturing element
        K=find(B==1);
       if(L(K)==1)
        D(i,j)=1;
        end
    end
end
subplot(3,4,14);
title('B1 Erode');
imshow(D);

A=z3;
%Struzturing element
B=[1 1 1 1 1 1 1;];
%Pad array with ones on both sides
z=padarray(A,[0 1],1);
%Intialize the matrix D of size A with zeros
D=false(size(A));
for i=1:size(z,1)
    for j=1:size(z,2)-2
        L=z(i,j:j+2);
 %Find the position of ones in the struzturing element
        K=find(B==1);
       if(L(K)==1)
        D(i,j)=1;
        end
    end
end
subplot(3,4,15);
title('B3 Erode');
imshow(D);

A=z1;
%Struzturing element
B=[1 1 1 1 1 1 1;];
%Pad array with ones on both sides
z=padarray(A,[0 1],1);
%Intialize the matrix D of size A with zeros
D=false(size(A));
for i=1:size(z,1)
    for j=1:size(z,2)-2
        L=z(i,j:j+2);
 %Find the position of ones in the struzturing element
        K=find(B==1);
       if(L(K)==1)
        D(i,j)=1;
        end
    end
end
subplot(3,4,16);
title('B7 Erode');
imshow(D);