function F = convolve(A, k)
[r, c] = size(A);
[m, n] = size(k);
z = rot90(k, 2);
mid = floor((size(z)+1)/2);
L = mid(2) - 1;
R = n - mid(2);
top = mid(1) - 1;
abc = m - mid(1);
st = zeros(r + top + abc, c + L + R);
for x = 1 + top : r + top
    for y = 1 + L : c + L
        st(x,y) = A(x - top, y - L);
    end
end
F = ones(r , c)-1;
for x = 1 : r
    for y = 1 : c
        for i = 1 : m
            for j = 1 : n
                q = x - 1;
                w = y -1;
                F(x, y) = F(x, y) + (st(i + q, j + w) * z(i, j));
            end
        end
    end
end