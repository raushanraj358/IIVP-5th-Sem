img = imread('C.jpg');

D = [5 25 0 6 9; 59 62 0 4 8; 24 36 0 7 8; 0 0 0 0 0; 8 7 0 36 24; 8 4 0 62 59; 9 6 0 25 5]/8;

[m,n] = size(img);

C = zeros(m+6,n+4);
C(4:end-3,3:end-2) = img;

LPF_C = zeros(m,n);

for x = 4:m+3
    for y = 3:n+2
        LPF_C(x-3,y-2) = sum(sum(C(x-3:x+3,y-2:y+2).*D));
    end
end

subplot(2,2,1);
imshow(img);
title('original');

subplot(2,2,2);
imshow(mat2gray(LPF_C));
title('LPF');

subplot(2,2,3);
imshow(mat2gray(double(img) - LPF_C));
title('HBF k=1')

subplot(2,2,4);
imshow(mat2gray(4*double(img) - LPF_C));
title('HBF k=4');





