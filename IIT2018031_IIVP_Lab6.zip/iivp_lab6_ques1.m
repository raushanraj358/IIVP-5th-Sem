 
I = imread("A.jpg");
B = [2 , 1, 9 ;
    7 , 18 ,6 ;
    0 , 1, 87];
dc = I(:, :, 1);
pc = I(:, :, 2);
st = I(:, :, 3);
A = convolve(double(dc), B);
C = convolve(double(pc), B);
D = convolve(double(st), B);
img = cat(3, A, C, D);
imshow (img);